<?php

header('Location: http://localhost/5lesson/registration.php');

?>